# altech-run-api-inspector

A lightweight in-app API inspector for React Native that helps developers monitor network activity without Flipper, Reactotron, or extra tooling.

It supports two debugging styles:
- UI overlay (floating `API` button + modal)
- Terminal-first console logs (no UI trigger)

## Why this package

- Works directly inside your app runtime
- Supports both `fetch` and `axios`
- Fast setup for teams that want quick network visibility
- Safe default for production (`__DEV__` guard)

## Features

- Intercept global `fetch`
- Support Axios request/response interceptors
- Floating button + request count badge
- API list with search and status filter
- API detail tabs: Overview, Request, Response, Headers
- Show method, URL, status, duration, headers, request/response body, and error
- Color status groups (`2xx`, `3xx`, `4xx`, `5xx`)
- Clear logs, copy JSON, open URL in browser, retry request
- Console mode with clean terminal output
- Browser dashboard with colorized JSON and per-section copy buttons (`Request Headers`, `Request Body`, `Response Headers`, `Response Body`)

## Installation

```bash
npm install altech-run-api-inspector zustand @react-native-clipboard/clipboard
```

If you use Axios:

```bash
npm install axios
```

## Optional Quick Setup (for package consumers)

After installing the package in your app project, you can auto-generate helper scripts:

```bash
npx altech-api-inspector setup
```

This command will:
- create `scripts/altech-api-inspector-dashboard.js`
- create `scripts/altech-api-inspector-adb-reverse.js`
- create `api-inspector.bootstrap.js` (auto inspector init + dashboard forwarding)
- auto-inject `import './api-inspector.bootstrap';` into your app entry file (`index.js`/`index.ts`)
- add scripts to your app `package.json`:
  - `api-inspector:dashboard`
  - `api-inspector:reverse`
  - `api-inspector:start`
  - `api-inspector:dev`
- add `concurrently` to `devDependencies` (if missing)

Then run:

```bash
npm install
npm run api-inspector:dev
```

Then start your app:

```bash
npm run android
# or
npm run ios
```

Browser dashboard opens automatically and starts receiving API logs (no manual inspector wiring required for fetch and default axios import).
Generated bootstrap uses dashboard-only logging by default (API logs are not printed in Metro terminal).

Axios note:
- auto setup can hook default `axios` import.
- if your app uses custom axios instances (`axios.create(...)`), attach them manually with `attachAxiosInspector(instance)`.

Port fallback behavior:
- dashboard tries `3939` first, then auto-fallback to next available port (`3940`, `3941`, ...).
- bootstrap forwarding also scans the same range automatically, so logs still arrive even if `3939` is busy.
- you can override start port with `API_INSPECTOR_DASHBOARD_PORT`.
- `api-inspector:start` also runs `adb reverse` for Metro (`8081`) and dashboard port range to help physical Android device connectivity.

Troubleshooting dashboard empty:
- check dashboard terminal, you should see `[dashboard] received #...` after API calls.
- if not, restart with clean setup:
  - `npx altech-api-inspector setup --force`
  - stop all old Metro/dashboard processes
  - `npm run api-inspector:dev`
- for Android emulator, keep `10.0.2.2` reachable; for physical Android, `adb reverse` is required (already executed by `api-inspector:start`).
- Metro bundle progress like `82%` is not an API-inspector failure by itself; logs should still appear after app finishes loading and requests run.

Note:
- This setup is optional.
- The package does **not** force-edit consumer `package.json` during normal install.
- If you already ran setup before and want to refresh generated files, run:
  - `npx altech-api-inspector setup --force`

## Usage

### Mode explained (`ui`, `console`, `both`)

- `ui`: show logs only in in-app inspector UI (floating button + modal).
- `console`: show logs only in Metro terminal (no UI trigger).
- `both`: show logs in both UI and Metro terminal.

Quick recommendation:
- choose `ui` if your team prefers in-app debugging.
- choose `console` if you do not want extra UI in the app.
- choose `both` when you want visual inspection and terminal history at the same time.

### 1) UI mode (default component usage)

```tsx
import { AltechApiInspector } from "altech-run-api-inspector";

export default function App() {
  return (
    <>
      <MainApp />
      {__DEV__ && <AltechApiInspector />}
    </>
  );
}
```

### 2) Console-only mode (no UI trigger)

Use this when you do not want floating button / modal.

```tsx
import { useEffect } from "react";
import { initApiInspector } from "altech-run-api-inspector";

export default function App() {
  useEffect(() => {
    const cleanup = initApiInspector({
      mode: "console",
      maxLogs: 100,
      console: { maxBodyLength: 800, verbosity: "compact" },
    });

    return cleanup;
  }, []);

  return <MainApp />;
}
```

### 3) Both UI + terminal logs

```tsx
<AltechApiInspector mode="both" />
```

### 4) Axios integration

```tsx
import axios from "axios";
import { attachAxiosInspector } from "altech-run-api-inspector";

if (__DEV__) {
  attachAxiosInspector(axios, { mode: "console" });
}
```

### 5) Send logs to a custom browser dashboard (optional)

```tsx
import { initApiInspector } from "altech-run-api-inspector";

const DASHBOARD_URL = "http://10.0.2.2:3939"; // Android emulator example

initApiInspector({
  mode: "console",
  console: {
    onLog: (log) => {
      const { retry, ...serializableLog } = log;
      fetch(`${DASHBOARD_URL}/logs`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(serializableLog),
      }).catch(() => undefined);
    },
  },
});
```

Important notes:
- `npm run dashboard` is a script from this repository's `ApiInspectorPlayground` example app.
- Package consumers do not need that script to use `altech-run-api-inspector`.
- In your own app/repo, you can create your own local server/dashboard and use `console.onLog` to forward logs there.

## Props

```ts
type AltechApiInspectorProps = {
  enabled?: boolean;
  maxLogs?: number;
  position?: "bottom-right" | "bottom-left" | "top-right" | "top-left";
  defaultOpen?: boolean;
  allowOpenInBrowser?: boolean;
  allowCopy?: boolean;
  mode?: "ui" | "console" | "both";
  showFloatingButton?: boolean;
  console?: {
    maxBodyLength?: number;
    verbosity?: "compact" | "detailed";
    showHeaders?: boolean;
    showTimestamp?: boolean;
    onLog?: (log: ApiLog) => void | Promise<void>;
  };
};
```

Defaults:
- `enabled = __DEV__`
- `maxLogs = 100`
- `position = "bottom-right"`
- `defaultOpen = false`
- `allowOpenInBrowser = true`
- `allowCopy = true`
- `mode = "ui"`
- `showFloatingButton = true`

## Console output style

Console mode prints readable blocks per request in Metro terminal:
- headline: method, status, duration, URL
- optional error line
- request/response headers and body (pretty JSON)
- long payload truncation with `... <truncated ... chars>` marker

Recommended setup:
- `verbosity: "compact"` for daily debugging (clean and short output).
- `verbosity: "detailed"` when you need full payload visibility.
- `showHeaders: true` only when debugging header-related issues.

## Public API

- `initApiInspector(options?)`
- `attachFetchInspector(options?)`
- `restoreFetchInspector()`
- `attachAxiosInspector(axiosInstance, options?)`

## Security notes

- Intended for development use.
- Disabled by default when `__DEV__` is false.
- Logs are memory-only (no storage persistence).
- Avoid exposing secrets in development payloads when possible.

## Roadmap

- Export logs to JSON file
- Sensitive data redaction helpers
- Endpoint grouping and aggregate latency metrics
- React Query / RTK Query helpers

## License

MIT
